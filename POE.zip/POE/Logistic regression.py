#3 logistic regression

#import dataset
import numpy as nm
import pandas as pd
import matplotlib.pyplot as mtp
import seaborn as sns 

#import dataset
data= pd.read_csv('User_Data.csv')

#independent and dependent variable
x= data.iloc[:,[2,3]].values
y= data.iloc[:,4].values

#splitting dataset
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test= train_test_split(x,y, test_size= 0.25, random_state=0)

#feature scaling
from sklearn.preprocessing import StandardScaler
st= StandardScaler()
x_train= st.fit_transform(x_train)
x_test= st.transform(x_test)

#fitting logistic regression
from sklearn.linear_model import LogisticRegression
classifier= LogisticRegression(random_state=0)
classifier.fit(x_train,y_train)

#prediction
y_pred= classifier.predict(x_test)

#creating confusion matrix
from sklearn.metrics import confusion_matrix
cm= confusion_matrix(y_test, y_pred)

#printing values
print('prediction', y_pred)

#actual value
print('actual values', y_test)

#Visualizing the training set result
from matplotlib.colors import ListedColormap
x_set, y_set = x_train, y_train
x1, x2 = nm.meshgrid(nm.arange(start = x_set[:, 0].min() - 1, stop = x_set[:, 0].max() + 1, step  =0.01),
nm.arange(start = x_set[:, 1].min() - 1, stop = x_set[:, 1].max() + 1, step = 0.01))
mtp.contourf(x1, x2, classifier.predict(nm.array([x1.ravel(), x2.ravel()]).T).reshape(x1.shape),
alpha = 0.75, cmap = ListedColormap(('purple','green' )))
mtp.xlim(x1.min(), x1.max())
mtp.ylim(x2.min(), x2.max())
for i, j in enumerate(nm.unique(y_set)):
    mtp.scatter(x_set[y_set == j, 0], x_set[y_set == j, 1],
        c = ListedColormap(('purple', 'green'))(i), label = j)
mtp.title('Logistic Regression Training set')
mtp.xlabel('Age')
mtp.ylabel('Estimatd salary')
mtp.legend()
mtp.show()